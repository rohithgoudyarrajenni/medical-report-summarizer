import unittest
from analyzer import analyze_report, generate_summary

class TestAnalyzer(unittest.TestCase):
    def setUp(self):
        self.report = """Hemoglobin: 10.5 g/dL (Reference range: 12.0-16.0)
WBC: 7500 cells/uL (Reference range: 4000-11000)
Glucose: 105 mg/dL (Reference range: 70-100)"""

    def test_extracts_three(self):
        self.assertEqual(len(analyze_report(self.report)), 3)

    def test_low_value(self):
        df = analyze_report(self.report)
        self.assertEqual(df.iloc[0]["Status"], "Below reference range")

    def test_high_value(self):
        df = analyze_report(self.report)
        self.assertEqual(df.iloc[2]["Status"], "Above reference range")

    def test_empty_input(self):
        self.assertTrue(analyze_report("").empty)

    def test_summary(self):
        self.assertIn("Tests analyzed", generate_summary(analyze_report(self.report)))

if __name__ == "__main__":
    unittest.main()
